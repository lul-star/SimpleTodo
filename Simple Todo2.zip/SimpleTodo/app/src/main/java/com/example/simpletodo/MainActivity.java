package com.example.simpletodo;

import android.os.Bundle;
import android.os.FileUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.w3c.dom.DOMException;

import java.io.File;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {

    List<String> items;

    Button btnadd;
    EditText etitem;
    RecyclerView rvItems;
    itemsadapter itemsadapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnadd = findViewById(R.id.btnadd);
        etitem = findViewById(R.id.etitem);
        rvItems = findViewById(R.id.rvItems);
        etitem.setText( "I am doing this from Java");

        loaditems();

        itemsadapter .OnLongClickLitsener = new itemsadapter.OnLongClickLitsener(){
            @Override
            public void onitemLongClicked(int position) {
                items.remove(position);
                itemsadapter.notifyItemRemoved(position);
                Toast.makeText(getApplicationContext(), "Item was removed", Toast.LENGTH_SHORT).show();
                saveitems();
            }
        };
        itemsadapter = new itemsadapter(items, com.example.simpletodo.itemsadapter.OnLongClickLitsener);
        rvItems.setAdapter(itemsadapter);
        rvItems.setLayoutManager(new LinearLayoutManager( this));

        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String todoItem = etitem.getText().toString();
                items.add(todoItem);
                itemsadapter.notifyItemInserted().size()-1);
                etitem.setText('');
                Toast.makeText(getApplicationContext(), "Item was added", Toast.LENGTH_SHORT).show();
                saveitems();
            }
        });


    }
    private File getDatafile;

    {
        return new File(getFilesDir(), "data.txt");
    }
        private void boolitems() {
    items = new ArrayList<>(FileUtils.readLines(getDatafile(), Charset.defaultCharset()));
    } catch (DOMException e){
        Log.e('MainActivity', 'Error reading item', e);
        items = new ArrayList<>();
    }

private void saveitems(){
        try{
            FileUtils.writeLines(getDatafile(), items);
        catch (DOMException e){
            Log.e(  'MainActivity', 'Error writing items', e);
            }
        }
}
}